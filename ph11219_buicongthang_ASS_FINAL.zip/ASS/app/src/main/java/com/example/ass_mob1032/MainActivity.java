package com.example.ass_mob1032;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnThemLop, btnDSLop, btnQuanLySV;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnThemLop = findViewById(R.id.btnThemLop);
        btnDSLop = findViewById(R.id.btnDSLop);
        btnQuanLySV = findViewById(R.id.btnQuanLySV);
    }

    public void themLop(View view) {
        intent = new Intent(MainActivity.this,ThemLopActivity.class);
        startActivity(intent);

    }

    public void danhSachLop(View view) {
        intent = new Intent(MainActivity.this,ListLopActivity.class);
        startActivity(intent);

    }

    public void quanLySV(View view) {
        intent = new Intent(MainActivity.this,QLSVActivity.class);
        startActivity(intent);

    }
}