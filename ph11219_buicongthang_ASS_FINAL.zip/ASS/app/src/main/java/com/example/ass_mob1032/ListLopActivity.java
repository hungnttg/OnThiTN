package com.example.ass_mob1032;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import controller.LopControl;

public class ListLopActivity extends AppCompatActivity {
    List<String> list;
    LopControl lopControl;
    ListView tblListLop;
    String textItem,subTextItem;
    int m_position = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_lop);
        tblListLop = findViewById(R.id.tblListLop);
        registerForContextMenu(tblListLop);
        lopControl = new LopControl(ListLopActivity.this);
        list = new ArrayList<>();
        list = lopControl.getAllLopString();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(ListLopActivity.this, android.R.layout.simple_list_item_1, list);
        tblListLop.setAdapter(adapter);
        tblListLop.deferNotifyDataSetChanged();
        tblListLop.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                textItem =(String)tblListLop.getItemAtPosition(position);
                subTextItem = textItem.substring(0,textItem.indexOf(" "));
                m_position = position;
                String ten = textItem.substring(textItem.indexOf("-")+1,textItem.indexOf("."));
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(Menu.NONE,0,0,"Xóa");
        menu.add(Menu.NONE,1,0,"Sửa");
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo menuInfo = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
        switch (item.getItemId()){
            case 0:
                Toast.makeText(this, "Context ID: "+item.getItemId()+" Ma Lop "+subTextItem, Toast.LENGTH_SHORT).show();
                try {
                    Toast.makeText(this, "Xoa thanh cong", Toast.LENGTH_SHORT).show();
                    lopControl.deleteLop(subTextItem);
                    list.remove(m_position);
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(ListLopActivity.this,android.R.layout.simple_list_item_1,list);
                    tblListLop.setAdapter(adapter);
                }catch (Exception e){
                    Toast.makeText(this, "Xoa that bai", Toast.LENGTH_SHORT).show();
                }

                break;
            case 1:
                Toast.makeText(this, "Context ID: "+item.getItemId()+" Ma Lop "+subTextItem, Toast.LENGTH_SHORT).show();
                Dialog dialog = new Dialog(this);
                dialog.setContentView(R.layout.dialog);
                dialog.show();
                break;
        }
        return super.onContextItemSelected(item);
    }
}