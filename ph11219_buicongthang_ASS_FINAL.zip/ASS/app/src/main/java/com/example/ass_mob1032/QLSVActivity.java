package com.example.ass_mob1032;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import controller.LopControl;
import model.SinhVien;

public class QLSVActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    List<String> sinhVienList = new ArrayList<>();
    List<String> list;
    Button btnThem;
    Spinner spnLop;
    EditText txtTenSV, txtNgaySinh;
    ListView lvSV;
    LopControl lopControl;
    String item;
    SinhVien sinhVien;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q_l_s_v);
        btnThem = findViewById(R.id.btnThem);
        spnLop = findViewById(R.id.spnLop);
        txtNgaySinh = findViewById(R.id.txtNgaySinh);
        txtTenSV = findViewById(R.id.txtTenSV);
        lvSV = findViewById(R.id.lvSV);
        lopControl = new LopControl(QLSVActivity.this);
        list =new ArrayList<>();
        list =lopControl.getAllLopString();
        spnLop.setOnItemSelectedListener(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(QLSVActivity.this, android.R.layout.simple_spinner_dropdown_item, list);
        spnLop.setAdapter(adapter);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        item = String.valueOf(parent.getItemAtPosition(position));
        Toast.makeText(this, "Selected: " + item.toString(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void themSinhVien(View view) {
        sinhVien = new SinhVien();
        sinhVien.setLop(item.toString());
        sinhVien.setTenSV(txtTenSV.getText().toString());
        sinhVien.setNgaySinh(txtNgaySinh.getText().toString());
        sinhVienList.add("Lớp: "+sinhVien.getLop()+" Tên sinh viên: "+sinhVien.getTenSV()+" Ngày sinh:  "+sinhVien.getNgaySinh());
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter(QLSVActivity.this,android.R.layout.simple_list_item_1,sinhVienList);
        lvSV.setAdapter(arrayAdapter);
    }

    public void xemDanhSach(View view) {
//        ArrayAdapter<String> arrayAdapter = new ArrayAdapter(QLSVActivity.this,android.R.layout.simple_list_item_1,sinhVienList);
//        lvSV.setAdapter(arrayAdapter);
    }
}