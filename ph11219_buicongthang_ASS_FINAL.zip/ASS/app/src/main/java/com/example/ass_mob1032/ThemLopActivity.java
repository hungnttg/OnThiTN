package com.example.ass_mob1032;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import controller.LopControl;
import model.Lop;

public class ThemLopActivity extends AppCompatActivity {
    EditText txtMaLop, txtTenLop;
    Button btnXoa,btnLuu,btnXemLop,btnUpdate;
    LopControl lopControl;
    ListView tblListLop;
    String textItem,subTextItem;
    List<String> list;
    int m_position = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_them_lop);
        txtMaLop = findViewById(R.id.txtMaLop);
        txtTenLop = findViewById(R.id.txtTenLop);
        btnLuu = findViewById(R.id.btnLuu);
        btnXoa = findViewById(R.id.btnXoa);
        btnXemLop =findViewById(R.id.btnXemLop);
        tblListLop = findViewById(R.id.tblListLop);
        btnUpdate = findViewById(R.id.btnUpdate);
        registerForContextMenu(tblListLop);
        lopControl = new LopControl(ThemLopActivity.this);
        btnLuu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Lop lop =new Lop();
                lop.setMaLop(txtMaLop.getText().toString());
                lop.setTenLop(txtTenLop.getText().toString());
                if(lopControl.insertLop(lop)<0){
                    Toast.makeText(ThemLopActivity.this, "Them that bai", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(ThemLopActivity.this, "Them thanh cong", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnXemLop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 list = new ArrayList<>();
                list = lopControl.getAllLopString();
                ArrayAdapter<String> adapter = new ArrayAdapter<>(ThemLopActivity.this,android.R.layout.simple_list_item_1,list);
                tblListLop.setAdapter(adapter);
                tblListLop.deferNotifyDataSetChanged();
            }
        });
        tblListLop.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                  textItem =(String)tblListLop.getItemAtPosition(position);
                  subTextItem = textItem.substring(0,textItem.indexOf(" "));
                  m_position = position;
                  String ten = textItem.substring(textItem.indexOf("-")+1,textItem.indexOf("."));
                  txtMaLop.setText(subTextItem);
                  txtTenLop.setText(ten);
            }
        });
        tblListLop.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Lop lop = new Lop();
                lop.setMaLop(txtMaLop.getText().toString());
                lop.setTenLop(txtTenLop.getText().toString());
                if(lopControl.updateLop(lop)<0){
                    Toast.makeText(ThemLopActivity.this, "Update that bai", Toast.LENGTH_SHORT).show();
                }else{
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(ThemLopActivity.this,android.R.layout.simple_list_item_1,list);
                    tblListLop.setAdapter(adapter);
                    Toast.makeText(ThemLopActivity.this, "Update thanh cong", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(Menu.NONE,0,0,"Xóa");
        menu.add(Menu.NONE,1,0,"Sửa");
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo menuInfo = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
        switch (item.getItemId()){
            case 0:
                Toast.makeText(this, "Context ID: "+item.getItemId()+" Ma Lop "+subTextItem, Toast.LENGTH_SHORT).show();
                try {
                    Toast.makeText(this, "Xoa thanh cong", Toast.LENGTH_SHORT).show();
                    lopControl.deleteLop(subTextItem);
                    list.remove(m_position);
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(ThemLopActivity.this,android.R.layout.simple_list_item_1,list);
                    tblListLop.setAdapter(adapter);
                }catch (Exception e){
                    Toast.makeText(this, "Xoa that bai", Toast.LENGTH_SHORT).show();
                }

                break;
            case 1:
                Toast.makeText(this, "Context ID: "+item.getItemId()+" Ma Lop "+subTextItem, Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onContextItemSelected(item);
    }
}