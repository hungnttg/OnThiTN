package model;

public class SinhVien {
    private String lop;
    private String tenSV;
    private String ngaySinh;

    public SinhVien() {
    }

    public SinhVien(String lop, String tenSV, String ngaySinh) {
        this.lop = lop;
        this.tenSV = tenSV;
        this.ngaySinh = ngaySinh;
    }

    public String getLop() {
        return lop;
    }

    public void setLop(String lop) {
        this.lop = lop;
    }

    public String getTenSV() {
        return tenSV;
    }

    public void setTenSV(String tenSV) {
        this.tenSV = tenSV;
    }

    public String getNgaySinh() {
        return ngaySinh;
    }

    public void setNgaySinh(String ngaySinh) {
        this.ngaySinh = ngaySinh;
    }
}
