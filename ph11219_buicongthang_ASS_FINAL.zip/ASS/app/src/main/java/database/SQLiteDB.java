package database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import controller.LopControl;

public class SQLiteDB extends SQLiteOpenHelper {
    private Context context;
    public static final String DB_NAME = "qlsv";
    public static final int VERSION = 1;

    public SQLiteDB(@Nullable Context context) {
        super(context, DB_NAME, null, VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(LopControl.SQL_TABLE_LOP);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+LopControl.TABLE_NAME);
    }
}
