package poly.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import poly.entity.Dealer;

@Controller
public class DealerController {

	@Autowired
	SessionFactory sessionFactory;

	@RequestMapping(value = "/index")
	public String index(Model model) {
		Session session = sessionFactory.openSession();
		List<Dealer> lstDealer = session.createCriteria(Dealer.class).list();
		model.addAttribute("lstDealer", lstDealer);
		return "index";
	}

	@RequestMapping(value = "/add")
	public String add() {
		return "add";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String submitAdd(HttpServletRequest request) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		String dealer_name = request.getParameter("dealer_name");
		String dealer_code = request.getParameter("dealer_code");
		String dealer_email = request.getParameter("dealer_email");
		String dealer_adress = request.getParameter("dealer_adress");
		String dealer_tel = request.getParameter("dealer_tel");
		String dealer_mgr_name = request.getParameter("dealer_mgr_name");
		int active_flag = Integer.parseInt(request.getParameter("active_flag"));
		Dealer dealer = new Dealer(dealer_code, dealer_name, dealer_email, dealer_tel, dealer_adress, dealer_mgr_name,
				active_flag);
		session.save(dealer);
		session.getTransaction().commit();
		return "redirect:/index.htm";
	}

	@RequestMapping(value = "/edit/{id}")
	public String edit(Model model, @PathVariable String id) {
		Session session = sessionFactory.openSession();
		Dealer dealer = (Dealer) session.get(Dealer.class, id);
		model.addAttribute("dealer", dealer);
		return "edit";
	}

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.POST)
	public String editSubmit(Model model, @PathVariable String id, HttpServletRequest request) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		String dealer_name = request.getParameter("dealer_name");
		String dealer_email = request.getParameter("dealer_email");
		String dealer_adress = request.getParameter("dealer_adress");
		String dealer_tel = request.getParameter("dealer_tel");
		String dealer_mgr_name = request.getParameter("dealer_mgr_name");
		int active_flag = Integer.parseInt(request.getParameter("active_flag"));
		Dealer dealer = new Dealer(id, dealer_name, dealer_email, dealer_tel, dealer_adress, dealer_mgr_name,
				active_flag);
		session.update(dealer);
		session.getTransaction().commit();
		model.addAttribute("dealer", dealer);
		return "redirect:/index.htm";
	}

	@RequestMapping(value = "/delete/{id}")
	public String delete(@PathVariable String id) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Dealer dealer = new Dealer();
		dealer.setDealer_code(id);
		session.delete(dealer);
		session.getTransaction().commit();
		return "redirect:/index.htm";
	}
	
	@RequestMapping(value="/search",method=RequestMethod.POST)
	public String search(HttpServletRequest request,Model model) {
		Session session = sessionFactory.openSession();
		String search = request.getParameter("search");
		List<Dealer> lstDealer = session.createCriteria(Dealer.class)
				.add(Restrictions.eq("dealer_code", search))
				.list();
		model.addAttribute("lstDealer", lstDealer);
		return "index";
	}

}
