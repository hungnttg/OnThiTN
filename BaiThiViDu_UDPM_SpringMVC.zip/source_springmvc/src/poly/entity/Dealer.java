package poly.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * @author Administrator
 *
 */
@Entity
public class Dealer {

	@Id
	private String dealer_code;
	
	private String dealer_name;
	
	private String dealer_email;
	
	private String dealer_tel;
	
	private String dealer_adress;
	
	private String dealer_mgr_name;
	
	private int active_flag;

	
	
	

	public Dealer(String dealer_code, String dealer_name, String dealer_email, String dealer_tel, String dealer_adress,
			String dealer_mgr_name, int active_flag) {
		super();
		this.dealer_code = dealer_code;
		this.dealer_name = dealer_name;
		this.dealer_email = dealer_email;
		this.dealer_tel = dealer_tel;
		this.dealer_adress = dealer_adress;
		this.dealer_mgr_name = dealer_mgr_name;
		this.active_flag = active_flag;
	}

	public String getDealer_email() {
		return dealer_email;
	}

	public void setDealer_email(String dealer_email) {
		this.dealer_email = dealer_email;
	}

	public String getDealer_code() {
		return dealer_code;
	}

	public void setDealer_code(String dealer_code) {
		this.dealer_code = dealer_code;
	}

	public String getDealer_name() {
		return dealer_name;
	}

	public void setDealer_name(String dealer_name) {
		this.dealer_name = dealer_name;
	}

	public String getDealer_tel() {
		return dealer_tel;
	}

	public void setDealer_tel(String dealer_tel) {
		this.dealer_tel = dealer_tel;
	}



	public String getDealer_adress() {
		return dealer_adress;
	}

	public void setDealer_adress(String dealer_adress) {
		this.dealer_adress = dealer_adress;
	}

	public String getDealer_mgr_name() {
		return dealer_mgr_name;
	}

	public void setDealer_mgr_name(String dealer_mgr_name) {
		this.dealer_mgr_name = dealer_mgr_name;
	}

	public int getActive_flag() {
		return active_flag;
	}

	public void setActive_flag(int active_flag) {
		this.active_flag = active_flag;
	}

	public Dealer() {
		super();
	}
	
	
}
